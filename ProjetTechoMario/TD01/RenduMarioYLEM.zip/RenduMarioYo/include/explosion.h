#ifndef EXPLOSION_IS_DEF
#define EXPLOSION_IS_DEF

#include "object.h"

/* #include "debug.h" */
/* #include "animation.h" */
/* #include "graphics.h" */

/* #include "error.h" */


void animation_explosion_from_missile_add (dynamic_object_t *obj);

int animation_explosion_onestep (dynamic_object_t *obj);

#endif
