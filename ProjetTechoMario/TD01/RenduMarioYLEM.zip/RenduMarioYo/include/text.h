#ifndef TEXT_IS_DEF
#define TEXT_IS_DEF

#include "object.h"
/* #include "animation.h" */
/* #include "debug.h" */

    void animation_text_add (dynamic_object_t *obj);

    int animation_text_onestep (dynamic_object_t *obj);

#endif
